<session class="sessions s6 row">
                <h1 class="session-title col-12">Im Kosover</h1>
                <div class="session-content">
                    <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia,</p>
                    <p>Until Now, We Have</p>
                </div>
                <div class="pie-chart col-12">
                    <div class="pie-chart-types col-3">
                        <div class="types type1">Knowledgeable Kosovar</div>
                        <div class="types type2">Social Kosovar</div>
                        <div class="types type3">Kind Kosovar</div>
                    </div>
                    <div class="pie-chart-frame col-6"><img src="img/pie-chart-frame.svg" alt="">
                        <div class="pie-chart-content"></div>
                    </div>
                    <div class="pie-chart-types col-3">
                        <div class="types type4">Activist Kosovar</div>
                        <div class="types type5">Ccreative Kosovar</div>
                        <div class="types type6">Activist Kosovar</div>
                    </div>
                </div>
                <button type="button" class="btn btn-primary btn-lg ">Do the test Now!</button>

</session>
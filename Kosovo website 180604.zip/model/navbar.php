<div class="navbar col-12">
            <img class="logo"src="img/mainLOGO.png" alt="">
            <div class="nav-BG">
                <img src="img/navBg.svg" alt="">
            </div>
            <div class="menuBG"></div>
            <ul class="nav" id="menu">
                <li class="nav-item lang"><a href="" class="al">al</a> / <a href="" class="en">en</a></li>
                <li class="nav-item menu-item1"><a class="nav-link" href="">About</a></li>
                <li class="nav-item menu-item2"><a class="nav-link" href="">10 Things</a></li>
                <li class="nav-item menu-item3"><a class="nav-link" href="">Future Vote</a></li>
                <li class="nav-item menu-item4"><a class="nav-link" href="">Childrem</a></li>
                <li class="nav-item menu-item5"><a class="nav-link" href="">Im Kosover</a></li>
                <li class="nav-item menu-item6"><a class="nav-link" href="">K missions</a></li>
                <li class="nav-item menu-item7"><a class="nav-link" href="">sponsers</a></li>
                <li class="space"></li>
                <li class="social-links"><i class="fab fa-instagram"><a href="google.com"></a></i></li>
                <li class="social-links"><i class="fab fa-facebook-f"><a href="google.com"></a></i></li>
            </ul>
</div>
<session class="sessions s4 row">
                <h1 class="session-title col-12">Future Vote</h1>
                <div class="session-content">
                    <p>What are the 10 most important achievements of Kosovo’s democracy in the past 10 years in your opinion? plz vote 3 of it</p>
                </div>
                <button type="button" class="btn btn-outline-secondary">
                is the declaration of its independence
                </button>
                <button type="button" class="btn btn-outline-secondary">
                is the electing of the first woman president of Kosovo. 
                </button>
                <button type="button" class="btn btn-outline-secondary">
                The rise and strengthening of the opposition leftist party in Kosovo
                </button>
                <button type="button" class="btn btn-outline-secondary">
                The decentralization of power and leadership in the municipal level
                </button>
                <button type="button" class="btn btn-outline-secondary">
                The civil society in Kosovo is quite strong and active compared to the years right after the conflict
                </button>
                <button type="button" class="btn btn-outline-secondary">
                is one of the first steps towards the accession in the European family.
                </button>
                <button type="button" class="btn btn-outline-secondary">
                has managed to become member of International Olympic Committee (IOC), FIFA and UEFA.
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Acknowledgment of the importance of human rights and the opening of discussions
                </button>
                <button type="button" class="btn btn-outline-secondary">vote</button>
                <button type="button" class="btn btn-outline-secondary">vote</button>

                <div class="session-content">
                    <p>What are the 10 things you want to change of Kosovo’s democracy or society?  plz vote 3 of it</p>
                </div>
                <button type="button" class="btn btn-outline-secondary">
                Fight against nepotism and corruption
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Reformed justice system and a country with strong rule of law
                </button>
                <button type="button" class="btn btn-outline-secondary">
                A strong, reformed and qualitative education system based on meritocracy and competencies
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Support for culture, arts and sports
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Economic development which will lower the staggering level of unemployment, especially among youngsters
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Visa liberalization and freedom of movement of goods, services and citizens in the European Union zone
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Increase foreign direct investments in the country
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Advancement of freedom of speech, freedom of beliefs and freedom of expression including freer media and journalism
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Gender perspective and gender sensitiveness shall be incorporated in every aspect of the society and economy in order to enhance the gender equality
                </button>
                <button type="button" class="btn btn-outline-secondary">
                Acceptance in important regional and international organizations and bodies such as EU, NATO, UN and its agencies, Interpol etc.
                </button>


</session>
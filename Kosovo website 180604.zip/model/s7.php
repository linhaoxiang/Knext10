<session class="sessions s7 row">
                <h1 class="session-title col-12">K missions</h1>
                <p class="session-content">Time to Explore Kosovo! Here is some mixxions to going through different aspects of Kosovo, and contributing their ideas for Kosovo’s future in the collective creation to share it with other visitors. </p>
                    <div class="mission-generater col-8"><img src="img/KmissionFrame.svg" alt=""></div>
</session>
<session class="sessions s5 row">
                <h1 class="session-title col-12">Childream</h1>
                <div class="col-8 ytframe">
                    <iframe id="ytplayer" type="text/html"
                    src="https://www.youtube.com/embed/izO7v8UIAdY?controls=0&disablekb=1&fs=0&rel=0&showinfo=0&color=white"
                    frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="col-4 s5-right">
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <button type="button" class="btn btn-primary btn-lg ">Youtube</button>
                </div>
                
</session>
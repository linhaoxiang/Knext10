<session class="sessions s1 row">
                <div class="col-9"><img src="img/s01_BG.png" alt=""></div>
                <div class="col-3 mainInfo">
                    <h6>Date:</h6>
                    <h4>2018.06.27 - 07.22</h4>
                    <h6>Venue:</h6>
                    <h4>Kosovo Museum / Lapidarium /
                            St.Nazim Gafurri, Pristina</h4>
                    <h6>Opening Hours</h6>
                    <h4>11:00 - 19:00</h4>
                    <h6>Organizer:</h6>
                    <h4>Taiwan and Kosovo Cultural Exchange Association</h4>
                    <h6>CO-Organizer:</h6>
                    <h4>Kosovo Museum</h4>
                </div>
</session>
<div class="footer">
            <div class="footer-content"><h1 class="session-title">Footer</h1></div>
            <div class="sponsers"><h1 class="session-title">Sponsers</h1></div>
</div>   